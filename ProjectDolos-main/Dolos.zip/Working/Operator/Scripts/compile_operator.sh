#!/bin/bash

javac -cp "../src/" -d "../bin/" ../src/Driver.java
