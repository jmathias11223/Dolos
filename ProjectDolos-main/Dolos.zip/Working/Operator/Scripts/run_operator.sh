#!/bin/bash

java -cp "../bin/" Driver 23.23.136.140 20000
