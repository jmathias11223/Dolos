#!/bin/bash

javac -cp "/home/admin/Server/src/" -d "/home/admin/Server/bin" /home/admin/Server/src/ServerDriver.java 
