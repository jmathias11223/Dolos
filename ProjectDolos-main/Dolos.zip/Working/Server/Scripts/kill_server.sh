#!/bin/bash

pkill -f java
