package DB;

public class DBTester {

    public static void main(String[] args) {
        try {
            // Database db = new Database("tester.db");

            // Add testing code here
            
        }
        catch (Exception e) { e.printStackTrace(); }
    }
}