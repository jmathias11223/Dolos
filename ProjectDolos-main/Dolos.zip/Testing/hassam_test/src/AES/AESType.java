package AES;

public enum AESType {
	AES128, AES192, AES256;
}
