# Survey target
---
Two files have been created to quickly survey the target if they are on Windows. Running just the script will collect system info and report current directory but will open a
promt and therefore not be invisible. To correct that, a windows script file was created that runs the first batch file in the background to remain invisible.
